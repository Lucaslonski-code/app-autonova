
interface Props {
  children: React.ReactNode;
}

export function Section({
  children,
}: Props) {
  return (
    <section className="mb-10">
      {children}
    </section>
  );
}

