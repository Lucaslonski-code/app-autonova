
import axios from "axios";

import { env } from "@/config/env";
import { cookieService } from "@/lib/cookies";

export const api = axios.create({

    baseURL: env.API_URL,

    timeout: 10000,

    headers:{

        "Content-Type":"application/json"

    }

});

api.interceptors.request.use((config)=>{

    const token = cookieService.getAccessToken();

    if(token){

        config.headers.Authorization=`Bearer ${token}`;

    }

    return config;

});

api.interceptors.response.use(

    (response)=>response,

    async(error)=>{

        return Promise.reject(error);

    }

);

export default api;
