
import { PageHeader } from "@/components/layout/PageHeader";

export default function PerfilPage(){

    return(

        <>

            <PageHeader

                title="Perfil"

                description="Informações da conta."

            />

        </>

    );

}

